const currentImage = document.getElementById('current-image');
const thumbnails = document.querySelectorAll('.thumbnail');
const prevButton = document.getElementById('prev');
const nextButton = document.getElementById('next');
const imageTitle = document.getElementById('image-title');
const imageDescription = document.getElementById('image-description');

let currentIndex = 0;

const images = [
    {
        src: 'lion.png',
        title: 'lion',
        description: 'Scientific Name: Panthera leo'
    },
    {
        src: 'zerafi.jpeg',
        title: 'zerafi',
        description: 'Scientific Name: Giraffa camelopardalis'
    },
    {
        src: 'tiger.png',
        title: 'tiger',
        description: 'Scientific Name: Panthera tigris'
    },
    {
        src: 'cat.jpg',
        title: 'cat',
        description: 'Scientific Name: Felis catus (domestic cat)'
    },
    {
        src: 'cow.jpeg',
        title: 'lion',
        description: 'Scientific Name: Panthera leo'
    },
    {
        src: 'dog.jpeg',
        title: 'zerafi',
        description: 'Scientific Name: Giraffa camelopardalis'
    },
    {
        src: 'hourse.jpeg',
        title: 'zerafi',
        description: 'Scientific Name: Giraffa camelopardalis'
    },
    {
        src: 'lepard.png',
        title: 'tiger',
        description: 'Scientific Name: Panthera tigris'
    }
];

function updateImageDetails(index) {
    currentImage.src = images[index].src;
    imageTitle.textContent = images[index].title;
    imageDescription.textContent = images[index].description;
}

thumbnails.forEach((thumbnail, index) => {
    thumbnail.addEventListener('click', () => {
        currentIndex = index;
        updateImageDetails(index);
    });
});

prevButton.addEventListener('click', () => {
    currentIndex = (currentIndex > 0) ? currentIndex - 1 : images.length - 1;
    updateImageDetails(currentIndex);
});

nextButton.addEventListener('click', () => {
    currentIndex = (currentIndex < images.length - 1) ? currentIndex + 1 : 0;
    updateImageDetails(currentIndex);
});
